﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Timers;
using ABB.Robotics;
using ABB.Robotics.Controllers;
using ABB.Robotics.Controllers.Discovery;
using ABB.Robotics.Controllers.RapidDomain;
using ABB.Robotics.Controllers.MotionDomain;


namespace demo1
{
    public partial class Form1 : Form /// 名叫 Form1 的类
    {
        private NetworkScanner scanner = null;
        private Controller controller = null;
        private NetworkWatcher networkwatcher = null;
        private MotionSystem aMotionSystem;
        private JointTarget aJointTarget;
        private MechanicalUnit aMechanicalUnit;
        private System.Timers.Timer aTimer = new System.Timers.Timer();

        public Form1()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.networkwatcher = new NetworkWatcher(scanner.Controllers);
            this.networkwatcher.Found += new EventHandler<NetworkWatcherEventArgs>(HandleFoundEvent);
            ///this.networkwatcher.Lost += new EventHandler<NetworkWatcherEventArgs>(HandleLostEvent);
            this.networkwatcher.EnableRaisingEvents = true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            this.scanner = new NetworkScanner(); this.scanner.Scan();
            ControllerInfoCollection controllers = scanner.Controllers; ListViewItem item = null;
            foreach (ControllerInfo controllerInfo in controllers)
            {
                item = new ListViewItem(controllerInfo.IPAddress.ToString());
                item.SubItems.Add(controllerInfo.Id);
                item.SubItems.Add(controllerInfo.Availability.ToString());
                item.SubItems.Add(controllerInfo.IsVirtual.ToString());
                item.SubItems.Add(controllerInfo.SystemName);
                item.SubItems.Add(controllerInfo.Version.ToString());
                item.SubItems.Add(controllerInfo.ControllerName);
                this.listView1.Items.Add(item);
                item.Tag = controllerInfo;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ListViewItem item = this.listView1.SelectedItems[0];//获取鼠标点选的机器人控制器
                if (controller != null)
                {
                    aTimer.Stop();
                    listView1.Items.Clear(); ///清空list
                    controller.Logoff();
                    controller.Dispose();
                    controller = null;
                    RoboStatusCon.Text = "Disconnected";
                    roboStatusIP.Text = "Null";
                    roboStatusAV.Text = "Unavailable";
                    roboStatusCN.Text = "Null";
                    MessageBox.Show("注销成功！", "注销");
                }

            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("请选择控制器后再进行操作。", "警告");
            }
        }


        void HandleFoundEvent(object sender, NetworkWatcherEventArgs e)
        {
            this.Invoke(new
            EventHandler<NetworkWatcherEventArgs>(AddControllerToListView), new Object[] { this, e });
        }

        private void AddControllerToListView(object sender, NetworkWatcherEventArgs e)
        {
            ControllerInfo controllerInfo = e.Controller;
            ListViewItem item = new ListViewItem(controllerInfo.IPAddress.ToString());
            item.SubItems.Add(controllerInfo.Id);
            item.SubItems.Add(controllerInfo.Availability.ToString());
            item.SubItems.Add(controllerInfo.IsVirtual.ToString());
            item.SubItems.Add(controllerInfo.SystemName);
            item.SubItems.Add(controllerInfo.Version.ToString());
            item.SubItems.Add(controllerInfo.ControllerName);
            item.Tag = controllerInfo;
        }

        [Obsolete]
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
                ListViewItem item = this.listView1.SelectedItems[0]; //获取鼠标点选的机器人控制器
                if (item.Tag != null)
                {
                    ControllerInfo controllerInfo = (ControllerInfo)item.Tag;
                    if (this.controller != null)
                    {
                        this.controller.Logoff();
                        this.controller.Dispose();
                    this.controller = null;
                    }
                    this.controller = ControllerFactory.CreateFrom(controllerInfo);
                    this.controller.Logon(UserInfo.DefaultUser);
                    RoboStatusCon.Text = "Connect Successed";
                    roboStatusIP.Text = controller.IPAddress.ToString();
                    roboStatusAV.Text = "Available";
                    roboStatusCN.Text = controllerInfo.ControllerName.ToString();
            }
            MessageBox.Show(this.controller.IPAddress + " : 登录成功！", "登录");
            aMotionSystem = controller.MotionSystem;
            SetRoboParam();
        }

        private void roboCon_Click(object sender, EventArgs e)
        {
            try
            {
                ListViewItem item = this.listView1.SelectedItems[0];//获取鼠标点选的机器人控制器
                if (item.Tag != null)
                {
                    ControllerInfo controllerInfo = (ControllerInfo)item.Tag;
                    if (this.controller != null)
                    {
                        this.controller.Logoff();
                        this.controller.Dispose();
                        this.controller = null;
                    }
                    this.controller = ControllerFactory.CreateFrom(controllerInfo);
                    this.controller.Logon(UserInfo.DefaultUser);
                    RoboStatusCon.Text = "Connect Successed";
                    roboStatusIP.Text = controller.IPAddress.ToString();
                    roboStatusAV.Text = "Available";
                    roboStatusCN.Text = controllerInfo.ControllerName.ToString();
                }
                MessageBox.Show(this.controller.IPAddress + " :登录成功！", "登录");
                aMotionSystem = controller.MotionSystem;
                SetRoboParam();
            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("请选择控制器后再进行操作。", "警告");
            }

            

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void stCon_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }


        void SetRoboParam()
        {
            aTimer.Elapsed += TimeRefreshPos;
            aTimer.Interval = 100;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }



        private void TimeRefreshPos(Object source, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                this.Invoke(new EventHandler <ElapsedEventArgs> (RefreshPos), new Object[] { this, e });
            }
            catch
            {
            }
        }

        private void RefreshPos(object sender, ElapsedEventArgs e)
        {
            GetRoboPos();
            GetRoboComp();
        }



        void GetRoboPos()
        {
            aJointTarget = controller.MotionSystem.ActiveMechanicalUnit.GetPosition();
            ax1Ang.Text = aJointTarget.RobAx.Rax_1.ToString();
            ax2Ang.Text = aJointTarget.RobAx.Rax_2.ToString();
            ax3Ang.Text = aJointTarget.RobAx.Rax_3.ToString();
            ax4Ang.Text = aJointTarget.RobAx.Rax_4.ToString();
            ax5Ang.Text = aJointTarget.RobAx.Rax_5.ToString();
            ax6Ang.Text = aJointTarget.RobAx.Rax_6.ToString();
            ax6Ang.Text = aJointTarget.RobAx.Rax_6.ToString();
            ax6Ang.Text = aJointTarget.RobAx.Rax_6.ToString();
            ax6Ang.Text = aJointTarget.RobAx.Rax_6.ToString();
        }
        void GetRoboComp()
        {
            aMechanicalUnit = aMotionSystem.ActiveMechanicalUnit;
            roboName.Text = controller.SystemName.ToString();
            wObjName.Text = aMechanicalUnit.WorkObject.ToString();
            wToolName.Text = aMechanicalUnit.Tool.ToString();
        }
    }





}
