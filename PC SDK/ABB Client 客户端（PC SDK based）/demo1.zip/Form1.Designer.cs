﻿namespace demo1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listView1 = new System.Windows.Forms.ListView();
            this.IPAdress = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Availability = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Virtual = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SystemName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.RobotWareVersion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ControllerName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.roborefresh = new System.Windows.Forms.Button();
            this.roboDiscon = new System.Windows.Forms.Button();
            this.roboCon = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.ax6Ang = new System.Windows.Forms.TextBox();
            this.ax5Ang = new System.Windows.Forms.TextBox();
            this.ax4Ang = new System.Windows.Forms.TextBox();
            this.ax3Ang = new System.Windows.Forms.TextBox();
            this.ax2Ang = new System.Windows.Forms.TextBox();
            this.ax1Ang = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.RoboStastus = new System.Windows.Forms.StatusStrip();
            this.RoboStatusCon = new System.Windows.Forms.ToolStripStatusLabel();
            this.roboStatusIP = new System.Windows.Forms.ToolStripStatusLabel();
            this.roboStatusAV = new System.Windows.Forms.ToolStripStatusLabel();
            this.roboStatusCN = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.roboName = new System.Windows.Forms.TextBox();
            this.wObjName = new System.Windows.Forms.TextBox();
            this.wToolName = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.RoboStastus.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.listView1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.IPAdress,
            this.ID,
            this.Availability,
            this.Virtual,
            this.SystemName,
            this.RobotWareVersion,
            this.ControllerName});
            this.listView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.listView1.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(3, 6);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(935, 264);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            // 
            // IPAdress
            // 
            this.IPAdress.Text = "IP Address";
            this.IPAdress.Width = 200;
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 100;
            // 
            // Availability
            // 
            this.Availability.Text = "Availability";
            this.Availability.Width = 100;
            // 
            // Virtual
            // 
            this.Virtual.Text = "Virtual";
            this.Virtual.Width = 80;
            // 
            // SystemName
            // 
            this.SystemName.Text = "System Name";
            this.SystemName.Width = 150;
            // 
            // RobotWareVersion
            // 
            this.RobotWareVersion.Text = "RobotWare Version";
            this.RobotWareVersion.Width = 150;
            // 
            // ControllerName
            // 
            this.ControllerName.Text = "Controller Name";
            this.ControllerName.Width = 150;
            // 
            // roborefresh
            // 
            this.roborefresh.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.roborefresh.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roborefresh.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.roborefresh.Location = new System.Drawing.Point(27, 344);
            this.roborefresh.Name = "roborefresh";
            this.roborefresh.Size = new System.Drawing.Size(95, 42);
            this.roborefresh.TabIndex = 1;
            this.roborefresh.Text = "REFRESH!!!";
            this.roborefresh.UseVisualStyleBackColor = false;
            this.roborefresh.Click += new System.EventHandler(this.button1_Click);
            // 
            // roboDiscon
            // 
            this.roboDiscon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.roboDiscon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roboDiscon.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.roboDiscon.Location = new System.Drawing.Point(158, 386);
            this.roboDiscon.Name = "roboDiscon";
            this.roboDiscon.Size = new System.Drawing.Size(95, 42);
            this.roboDiscon.TabIndex = 2;
            this.roboDiscon.Text = "Disconnect\r\nController";
            this.roboDiscon.UseVisualStyleBackColor = false;
            this.roboDiscon.Click += new System.EventHandler(this.button2_Click);
            // 
            // roboCon
            // 
            this.roboCon.BackColor = System.Drawing.Color.Lime;
            this.roboCon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.roboCon.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.roboCon.Location = new System.Drawing.Point(158, 297);
            this.roboCon.Name = "roboCon";
            this.roboCon.Size = new System.Drawing.Size(95, 42);
            this.roboCon.TabIndex = 3;
            this.roboCon.Text = "Connect\r\nController";
            this.roboCon.UseVisualStyleBackColor = false;
            this.roboCon.Click += new System.EventHandler(this.roboCon_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-2, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(964, 505);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.roboCon);
            this.tabPage1.Controls.Add(this.roboDiscon);
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Controls.Add(this.roborefresh);
            this.tabPage1.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(956, 473);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "控制器列表";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(956, 473);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "运动单元情况";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 19);
            this.label1.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox13);
            this.panel1.Controls.Add(this.textBox12);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.ax6Ang);
            this.panel1.Controls.Add(this.ax5Ang);
            this.panel1.Controls.Add(this.ax4Ang);
            this.panel1.Controls.Add(this.ax3Ang);
            this.panel1.Controls.Add(this.ax2Ang);
            this.panel1.Controls.Add(this.ax1Ang);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 448);
            this.panel1.TabIndex = 2;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.Window;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Location = new System.Drawing.Point(358, 409);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(25, 19);
            this.textBox13.TabIndex = 18;
            this.textBox13.Text = "°";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.Window;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Location = new System.Drawing.Point(358, 336);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(25, 19);
            this.textBox12.TabIndex = 17;
            this.textBox12.Text = "°";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.Window;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(358, 263);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(25, 19);
            this.textBox11.TabIndex = 16;
            this.textBox11.Text = "°";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Window;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Location = new System.Drawing.Point(358, 200);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(25, 19);
            this.textBox10.TabIndex = 15;
            this.textBox10.Text = "°";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Window;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Location = new System.Drawing.Point(358, 129);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(25, 19);
            this.textBox9.TabIndex = 14;
            this.textBox9.Text = "°";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Window;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Location = new System.Drawing.Point(358, 62);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(25, 19);
            this.textBox8.TabIndex = 13;
            this.textBox8.Text = "°";
            // 
            // ax6Ang
            // 
            this.ax6Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax6Ang.Location = new System.Drawing.Point(183, 409);
            this.ax6Ang.Name = "ax6Ang";
            this.ax6Ang.ReadOnly = true;
            this.ax6Ang.Size = new System.Drawing.Size(169, 26);
            this.ax6Ang.TabIndex = 12;
            this.ax6Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ax5Ang
            // 
            this.ax5Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax5Ang.Location = new System.Drawing.Point(183, 336);
            this.ax5Ang.Name = "ax5Ang";
            this.ax5Ang.ReadOnly = true;
            this.ax5Ang.Size = new System.Drawing.Size(169, 26);
            this.ax5Ang.TabIndex = 11;
            this.ax5Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ax4Ang
            // 
            this.ax4Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax4Ang.Location = new System.Drawing.Point(183, 263);
            this.ax4Ang.Name = "ax4Ang";
            this.ax4Ang.ReadOnly = true;
            this.ax4Ang.Size = new System.Drawing.Size(169, 26);
            this.ax4Ang.TabIndex = 10;
            this.ax4Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ax3Ang
            // 
            this.ax3Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax3Ang.Location = new System.Drawing.Point(183, 197);
            this.ax3Ang.Name = "ax3Ang";
            this.ax3Ang.ReadOnly = true;
            this.ax3Ang.Size = new System.Drawing.Size(169, 26);
            this.ax3Ang.TabIndex = 9;
            this.ax3Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ax2Ang
            // 
            this.ax2Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax2Ang.Location = new System.Drawing.Point(183, 126);
            this.ax2Ang.Name = "ax2Ang";
            this.ax2Ang.ReadOnly = true;
            this.ax2Ang.Size = new System.Drawing.Size(169, 26);
            this.ax2Ang.TabIndex = 8;
            this.ax2Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ax1Ang
            // 
            this.ax1Ang.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ax1Ang.Location = new System.Drawing.Point(183, 62);
            this.ax1Ang.Name = "ax1Ang";
            this.ax1Ang.ReadOnly = true;
            this.ax1Ang.Size = new System.Drawing.Size(169, 26);
            this.ax1Ang.TabIndex = 7;
            this.ax1Ang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(3, 409);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(64, 26);
            this.textBox7.TabIndex = 6;
            this.textBox7.Text = "Axis 6";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(3, 336);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(64, 26);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "Axis 5";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(3, 263);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(64, 26);
            this.textBox5.TabIndex = 4;
            this.textBox5.Text = "Axis 4";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(3, 197);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(64, 26);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "Axis 3";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(3, 126);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(64, 26);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "Axis 2";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Info;
            this.textBox2.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox2.Location = new System.Drawing.Point(130, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(76, 29);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "轴信息";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(64, 26);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Axis 1";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // RoboStastus
            // 
            this.RoboStastus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RoboStatusCon,
            this.roboStatusIP,
            this.roboStatusAV,
            this.roboStatusCN});
            this.RoboStastus.Location = new System.Drawing.Point(0, 515);
            this.RoboStastus.Name = "RoboStastus";
            this.RoboStastus.Size = new System.Drawing.Size(963, 22);
            this.RoboStastus.TabIndex = 5;
            this.RoboStastus.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.stCon_ItemClicked);
            // 
            // RoboStatusCon
            // 
            this.RoboStatusCon.Name = "RoboStatusCon";
            this.RoboStatusCon.Size = new System.Drawing.Size(86, 17);
            this.RoboStatusCon.Text = "Disconnected";
            // 
            // roboStatusIP
            // 
            this.roboStatusIP.Name = "roboStatusIP";
            this.roboStatusIP.Size = new System.Drawing.Size(39, 17);
            this.roboStatusIP.Text = "NULL";
            // 
            // roboStatusAV
            // 
            this.roboStatusAV.Name = "roboStatusAV";
            this.roboStatusAV.Size = new System.Drawing.Size(75, 17);
            this.roboStatusAV.Text = "Unavailable";
            // 
            // roboStatusCN
            // 
            this.roboStatusCN.Name = "roboStatusCN";
            this.roboStatusCN.Size = new System.Drawing.Size(75, 17);
            this.roboStatusCN.Text = "Empty User";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.Info;
            this.textBox14.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox14.Location = new System.Drawing.Point(173, 3);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(190, 29);
            this.textBox14.TabIndex = 4;
            this.textBox14.Text = "其他机器人参数信息";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.wToolName);
            this.panel2.Controls.Add(this.wObjName);
            this.panel2.Controls.Add(this.roboName);
            this.panel2.Controls.Add(this.textBox17);
            this.panel2.Controls.Add(this.textBox16);
            this.panel2.Controls.Add(this.textBox15);
            this.panel2.Controls.Add(this.textBox14);
            this.panel2.Location = new System.Drawing.Point(400, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(549, 448);
            this.panel2.TabIndex = 5;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(64, 200);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(162, 26);
            this.textBox15.TabIndex = 5;
            this.textBox15.Text = "工件(wObj)坐标名称";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(64, 329);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(162, 26);
            this.textBox16.TabIndex = 6;
            this.textBox16.Text = "工具(wTool)坐标名称";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(64, 90);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(162, 26);
            this.textBox17.TabIndex = 7;
            this.textBox17.Text = "机器人名称";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // roboName
            // 
            this.roboName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.roboName.Location = new System.Drawing.Point(307, 90);
            this.roboName.Name = "roboName";
            this.roboName.ReadOnly = true;
            this.roboName.Size = new System.Drawing.Size(215, 26);
            this.roboName.TabIndex = 8;
            this.roboName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wObjName
            // 
            this.wObjName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.wObjName.Location = new System.Drawing.Point(307, 200);
            this.wObjName.Name = "wObjName";
            this.wObjName.ReadOnly = true;
            this.wObjName.Size = new System.Drawing.Size(215, 26);
            this.wObjName.TabIndex = 9;
            this.wObjName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // wToolName
            // 
            this.wToolName.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.wToolName.Location = new System.Drawing.Point(307, 329);
            this.wToolName.Name = "wToolName";
            this.wToolName.ReadOnly = true;
            this.wToolName.Size = new System.Drawing.Size(215, 26);
            this.wToolName.TabIndex = 10;
            this.wToolName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(963, 537);
            this.Controls.Add(this.RoboStastus);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("YaHei Consolas Hybrid", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "今天想打拳击";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.RoboStastus.ResumeLayout(false);
            this.RoboStastus.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader IPAdress;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader Availability;
        private System.Windows.Forms.ColumnHeader Virtual;
        private System.Windows.Forms.ColumnHeader SystemName;
        private System.Windows.Forms.ColumnHeader RobotWareVersion;
        private System.Windows.Forms.ColumnHeader ControllerName;
        private System.Windows.Forms.Button roborefresh;
        private System.Windows.Forms.Button roboDiscon;
        private System.Windows.Forms.Button roboCon;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.StatusStrip RoboStastus;
        private System.Windows.Forms.ToolStripStatusLabel RoboStatusCon;
        private System.Windows.Forms.ToolStripStatusLabel roboStatusIP;
        private System.Windows.Forms.ToolStripStatusLabel roboStatusAV;
        private System.Windows.Forms.ToolStripStatusLabel roboStatusCN;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox ax6Ang;
        private System.Windows.Forms.TextBox ax5Ang;
        private System.Windows.Forms.TextBox ax4Ang;
        private System.Windows.Forms.TextBox ax3Ang;
        private System.Windows.Forms.TextBox ax2Ang;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox ax1Ang;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.TextBox wToolName;
        public System.Windows.Forms.TextBox wObjName;
        public System.Windows.Forms.TextBox roboName;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
    }
}

